<?php
session_start();

include "vendor/autoload.php";
include "config/app.php";
include "config/database.php";

include "views/frontend/index.php";
